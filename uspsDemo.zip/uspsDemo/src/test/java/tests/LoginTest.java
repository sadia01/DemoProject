package tests;

import data.CredentialsDataProvider;
import drivers.BaseDriver;
import drivers.PageDriver;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;
import pages.P001_LoginPage;

public class LoginTest extends BaseDriver {

    @Test(dataProvider = "loginData", dataProviderClass = CredentialsDataProvider.class, enabled = false) // Disabled by default
    public void testLoginDataProvider(String dataProviderEmail, String dataProviderPassword) throws InterruptedException {
        WebDriver driver = PageDriver.getDriver();
        driver.get(urlName);
        P001_LoginPage loginPage = new P001_LoginPage(driver);
        loginPage.fillLoginDetails(dataProviderEmail, dataProviderPassword);
    }

    @Test
    public void testLoginCommandLine() throws InterruptedException {
        if (loginEmail != null && loginPassword != null && urlName != null) { // Check for command-line args
            WebDriver driver = PageDriver.getDriver();
            driver.get(urlName);
            P001_LoginPage loginPage = new P001_LoginPage(driver);
            loginPage.fillLoginDetails(loginEmail, loginPassword);
        } else {
            // If command line arguments are NOT provided, run the data provider test
            testLoginDataProvider(null, null); // Call the data provider test (it will use the dataprovider values)
        }
    }
}