package drivers;

import org.openqa.selenium.WebDriver;
import java.util.ArrayList;
import java.util.List;

public class PageDriver {

    private static final ThreadLocal<WebDriver> driver = new ThreadLocal<>();
    private static final List<WebDriver> driverPool = new ArrayList<>(); // You can keep this for other purposes

    public static WebDriver getDriver() {
        return driver.get();
    }

    public static synchronized void setDriver(WebDriver webDriver) {
        driver.set(webDriver);
        driverPool.add(webDriver); // Keep track of drivers if needed
    }

    public static void quitDriver() { // Corrected quit method
        WebDriver currentDriver = driver.get();
        if (currentDriver != null) {
            currentDriver.quit();
            driver.remove(); // VERY IMPORTANT: Remove the driver from ThreadLocal
        }
    }

    public static void quitAllDrivers() { // Useful if you still have a need for it.
        WebDriver currentDriver = driver.get();
        while (currentDriver != null) {
            currentDriver.quit();
            driver.remove();
            currentDriver = driver.get(); // Get the next driver
        }
        driverPool.clear(); // Clear the pool too if you're using it
    }
}