package drivers;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

public class BaseDriver {
    protected WebDriver driver;
    public String urlName;
    protected Properties prop;
    public String loginEmail;
    public String loginPassword;
    public String browserName;

    @BeforeMethod(alwaysRun = true)
    public void setUp() throws IOException {
        prop = new Properties();
        String environment = System.getProperty("env");

        String propertiesFileName = "GlobalData.properties";
        if (environment != null) {
            propertiesFileName = "GlobalData_" + environment + ".properties";
        }

        try {
            FileInputStream fis = new FileInputStream(System.getProperty("user.dir") +
                    "\\src\\test\\java\\data\\" + propertiesFileName);
            prop.load(fis);
        } catch (IOException e) {
            System.out.println("Properties file not found. Using default or command-line values.");
        }

        // 1. Browser: Command line > Properties file > Default (Chrome)
        browserName = System.getProperty("browser") != null ? System.getProperty("browser") : prop.getProperty("browser");
        if (browserName == null) {
            browserName = "chrome"; // Default browser
        }

        // 2. URL: Command line > Properties file
        urlName = System.getProperty("url") != null ? System.getProperty("url") : prop.getProperty("url");
        if (urlName == null) {
            throw new IllegalArgumentException("URL is not defined. Please provide it via command line or properties file.");
        }

        // 3. Username: Command line > Properties file
        loginEmail = System.getProperty("username") != null ? System.getProperty("username") : prop.getProperty("username");

        // 4. Password: Command line > Properties file
        loginPassword = System.getProperty("password") != null ? System.getProperty("password") : prop.getProperty("password");


        // Browser setup
        if (browserName.contains("chrome")) {
            ChromeOptions options = new ChromeOptions();
            WebDriverManager.chromedriver().setup();
            if (browserName.contains("headless")) {
                options.addArguments("headless");
            }
            driver = new ChromeDriver(options);
        } else if (browserName.equalsIgnoreCase("firefox")) {
            WebDriverManager.firefoxdriver().setup();
            driver = new FirefoxDriver();
        } else if (browserName.equalsIgnoreCase("edge")) {
            WebDriverManager.edgedriver().setup();
            driver = new EdgeDriver();
        } else {
            throw new IllegalArgumentException("Invalid browser name: " + browserName);
        }

        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.manage().window().maximize();

        PageDriver.setDriver(driver);
    }

    @AfterMethod(alwaysRun = true)
    public void tearDown() {
        System.out.println("AfterMethod: Quitting the driver");
        PageDriver.quitDriver();
    }
}